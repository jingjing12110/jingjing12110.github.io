# 可行驶区域检测


## INSTALL

1. ros环境

```
roscore
```

2. 终端

```
rosrun image_transport republish compressed in:=/camera/image_color raw out:=/camera/image_color
```

3. 播放数据集

```
rosbag play name.bag -l
```

## 代码编译

```
1. catkin_make
2. source ./devel/setup.bash
3. rosrun travel_area_dect DAdect_main
```

## 参数修改
对于学校和常熟的数据，有两个文件需要修改：`main.cpp`  | `travel_area_dect.cpp`


