﻿/*!
* \file common_function.h
* \brief 基础函数头文件
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/
#ifndef COMMON_FUNCTION_H
#define COMMON_FUNCTION_H

#include "common_include.h"

/** @name 函数JudgeFlag2中使用的宏定义
* @{
*/
#define Ymax 20	 ///< 俯视栅格最大Y
#define Ymin -20	 ///< 俯视栅格最小Y
#define Xmax 40	 ///< 俯视栅格最大X
#define Xmin 0	 ///< 俯视栅格最小X
#define Birdpixel 0.2  ///< 俯视栅格大小
/** @}*/

/** @name 图像相关宏定义
* @{
*/
#define imgX 0	 ///< 图像左上角的X坐标
#define imgY 0   ///< 图像左上角的Y坐标
#define imgWidth 1384 - imgX  ///< 图像宽度
#define imgHeight 512 - imgY  ///< 图像高度
#define WidthAdd 5	  ///< 为消除三角剖分边界问题设置的宽度余量
#define HighAdd 10    ///< 为消除三角剖分边界问题设置的高度余量
#define save_res 0    ///< 1表示保存结果到图片
#define plot_point 1  ///< 1表示把点plot在图像上
#define silence 0 ///< 1表示打印每一步的用时信息
/** @}*/

/**
* @brief  阈值

* 三角剖分中过长的的边将被删掉，
* 通过法向量大小判断点是否为障碍物点
*/
struct Threshold {
  double squareD_uv = 2500;            /*!< 边长平方最大值 */
  double average_normal_cos = 0.1469;  /*!< 法向量余弦值阈值 */
};


/**
* @brief  点云数据

* 存储点云空间位置(xyz)与其投影后的图像位置(uv)
*/
struct ProcessVeloData {
  int size_velo2img;   /*!< 点的个数 */
  float(*uv_xyz)[5];   /*!< 点云与其在图像坐标的投影 */
};

/**
* @brief 点云与图像区域相对位置数据

* 保存每个雷达点所在扇形区域bin的序号和与底边中点的距离
*/
struct VeloBD {
  int* bin_index; /*!<雷达点所在bin的序号*/
  int* dist;      /*!<雷达点与底边中点的距离*/
};


/**
* @brief 找到点的位置对应的扇形序号

详细说明：用于结构体dataTable初始化的查找函数
* @param[in] p_cos 点坐标与起点的角度
* @param[in] angle_cos[360] 角度对应扇形区域的查找表
* @return 点对应的扇形序号
*/
int FindIdx(double p_cos, double angle_cos[360]);


/**
* @brief 判断某图像位置是否在图像平面内

详细说明：主要用来判断点云投影点是否落在图像平面内
* @param[in] u 待判断点坐标点横坐标
* @param[in] v 待判断点坐标点纵坐标
* @param[in] u_max 图像内最大横坐标
* @param[in] v_max 图像内最大纵坐标
* @return 1:投影点在图像平面内 0:不在
*/
bool IsTrue(float u, float v, float u_max, float v_max);



/**
* 矩阵A(x*y)与矩阵B(y*z)的矩阵乘法
* @param[in] a 矩阵A
* @param[in] b 矩阵B
* @param[in] x 矩阵维度x
* @param[in] y 矩阵维度y
* @param[in] z 矩阵维度z
* @param[out] c 计算结果
*/
void MatrixMultiply(double a[], double b[], double c[], 
					          int x, int y, int z);

/**
* 二维矩阵转置
* @param[in] A 待转置矩阵A
* @param[in] m 矩阵行数
* @param[in] m 矩阵列数
* @param[out] B 计算结果
*/
double* MatrixInver(double A[], int m, int n);

//
/**
* @brief 计算图像剪裁后的投影矩阵

详细说明：图像裁剪后，图像坐标系的坐标原点位置发生变化，需要相应地
调整投影矩阵。
* @param[in] camera_intrinsic_param 内参矩阵
* @param[in] velo_camera_extrinsic_param 外参矩阵
* @param[in] dx 新的图像坐标系原点在旧图像坐标的横坐标位置
* @param[in] dy 新的图像坐标系原点在旧图像坐标的纵坐标位置
* @param[out] P_velo_img 调整后的投影矩阵
*/
void ProjectMatrixRenew(double camera_intrinsic_param[12],
                        double velo_camera_extrinsic_param[16], 
						            double dx, double dy, 
						            double P_velo_img[12]);

/**
* @brief 对flag=2的点进行判断

* 详细说明：如果flag=2,即不确定该点是否为障碍物点，需进一步计算判断。
* 具体根据其周围区域的flag进行判断。只要四周存在障碍点，则认定为障碍点，否则为非障碍点
* @param[in] uv_xyz 点云及其投影数据
* @param[in] points 点云投影于图像的坐标
* @param[in] img 原始图像
* @param[in] is_show 是否可视化经过这一步处理后的图像和点云投影
* @param[out] flag 点的标签。0:非障碍物; 1:障碍物;
*/
void JudgeFlag2(float (*uv_xyz)[5], int* flag, vector<Point2f> points, 
				        Mat img, int isShow);

/**
* @brief 给出线段两端坐标值，画出连线

详细说明：在图像上画线，对可形式区域进行可视化
* @param[in] img 原始图像
* @param[in] start 起点坐标，在本项目中一般为图像底边中点（base_pt）
* @param[in] end 终点坐标
*/
void MyLine(Mat img, Point start, Point end);

// 在线测试未用
//字符分割函数
void Split(const string& src, const string& sep, vector<string>& ans);

//计算投影矩阵函数-仅用于类似kitti数据集读取提供参数
void ProjectMatrix(double P_velo_to_img[12]);  

//确定txt文件的行数
int ReadTxtLines(string velo_file);

// read offline data(txt)
void ReadVeloData(string velo_file, double (*lidar)[4], int LINES);

#endif
