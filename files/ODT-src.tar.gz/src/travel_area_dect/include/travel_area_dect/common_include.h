﻿/*!
* \file common_include.h
* \brief 通用外部库函数头文件
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/
#ifndef COMMON_INCLUDE_H
#define COMMON_INCLUDE_H

// std
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iosfwd>
#include <iostream>
#include <sstream>

#include <memory>
#include <string>
#include <vector>
#include <iosfwd>
#include <list>
#include <math.h>
#include <time.h>
#include <cmath>
#include <iomanip>
// opencv
#include <opencv/cv.h>
#include <opencv/cv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/core/core.hpp"
// pcl

using namespace std;
using namespace cv;

#endif
