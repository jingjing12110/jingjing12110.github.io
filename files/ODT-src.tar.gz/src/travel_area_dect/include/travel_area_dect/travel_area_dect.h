﻿/*!
* \file travel_area_dect.h
* \brief 可行驶区域函数头文件
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/
#ifndef TRAVEL_AREA_DECT_H
#define TRAVEL_AREA_DECT_H

#include "common_function.h"
#include "common_include.h"
#include "triangulation_2d.h"

// 可行驶区域检测的主体函数
void TravelAreaDect(int LINES, double (*lidar)[4], Mat img, Size size1);

#endif