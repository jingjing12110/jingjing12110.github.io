﻿/*!
* \file triangulation_2d.h
* \brief 三角剖分相关函数头文件
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/
#ifndef TRIANGULATION_2D_H
#define TRIANGULATION_2D_H

#include "common_function.h"
#include "common_include.h"


/**
* 将点云从三维空间投影到在图像平面坐标系
* @param[in] LINES 实际使用到的点数量
* @param[in] lidar 点云数据
* @param[in] P_velo_to_img 投影矩阵
* @param[in] size1 图像的大小
* @return pVD 初始的点云及其投影
* @retval ProcessVeloData结构体 pVD
*/
ProcessVeloData ProjectVelo2Img(int LINES, double (*lidar)[4],
                                double P_velo_to_img[12], Size size1);

/**
* @brief 将点云中位置重叠的点删除

* 详细说明：点云中可能存在空间位置重叠的点（双回波模式），这样的点在构建三角剖分的时候，
* 会导致opencv的三角剖分库函数出现问题，所以需要将重叠点删除。
* @param[in] LINES 实际使用到的点数量
* @param[in] lidar 点云数据
* @param[in] P_velo_to_img 投影矩阵
* @param[in] size1 图像的大小
* @retval ProcessVeloData结构体 pVD 包含点云及其投影
*/
ProcessVeloData DeleteDuplicatePoints(ProcessVeloData pVD_org);

/**
* @brief 稀疏化减采样

* 详细说明：为了提高程序运行速度，同时避免投影到图像坐标系的雷达点之间间距过小，导致三角剖分法向量不可靠的问题，
* 该函数实现了一种对雷达点的稀疏化减采样。即对任意投影到图像上的点，判断其图像邻域内（邻域大小由变量sparse_subsample_rate决定）
* 是否包含其他雷达点，没有则保留该点，否则舍弃该点。
* @param[in] pVD_org ProcessVeloData结构体，包含点云及其投影信息
* @param[out] pVD 处理后的ProcessVeloData结构体，包含点云及其投影信息
*/
ProcessVeloData Downsampling(ProcessVeloData pVD_org);

/**
* @brief 求三角形的法向量

* 详细说明：已知空间三角形每个顶点的空间位置，则可以计算该三角形的法向量
* @param[in] A_x 三角形顶点A的空间坐标x
* @param[in] A_y 三角形顶点A的空间坐标y
* @param[in] A_z 三角形顶点A的空间坐标z
* @param[in] B_x 三角形顶点B的空间坐标x
* @param[in] B_y 三角形顶点B的空间坐标y
* @param[in] B_z 三角形顶点B的空间坐标z
* @param[in] C_x 三角形顶点C的空间坐标x
* @param[in] C_y 三角形顶点C的空间坐标y
* @param[in] C_z 三角形顶点C的空间坐标z
* @return tri 三角形的法向量(与水平面余弦的平方)
*/
double Normal(double A_x, double A_y, double A_z, double B_x, double B_y,
              double B_z, double C_x, double C_y, double C_z, double tri);


/**
* @brief 计算每个激光点的法向量

* 详细说明：为了判断每个激光点是否可行驶，需要计算其法向量。
* 对于某一点，首先找到以该点顶点的所有空间三角形。
* 然后，计算每个三角形的法向量。
* 最后将这些三角形的法向量平均，记为该点的法向量。
* @param[in] uv_xyz 点云空间位置及其投影位置
* @param[in] thr 法向量阈值，用于判断点是否为障碍物点
* @param[in] points vector形式的点云，用于可视化
* @param[in] subdiv opencv创建的三角剖分类Subdiv2D
* @param[in] img 图像
* @param[in] is_show 是否可视化这一步
* @param[out] flag 点云是否为可行驶点的标志位
*/
void NormalTriangulation(float (*uv_xyz)[5], Threshold thr,
                         vector<Point2f> points, Subdiv2D subdiv, Mat img,
                         int *flag, int is_show);

/**
* @brief 三角剖分结果可视化

* 详细说明：将得到的三角剖分可视化到二维图像上，用于调试
* @param[in] subdiv opencv创建的三角剖分类Subdiv2D
* @param[in] rect 控制可视化范围
* @param[in] img 图像
*/
void ShowTriangulationResult(Subdiv2D subdiv, Rect rect, Mat img);

#endif