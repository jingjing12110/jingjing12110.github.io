/*!
* \file common_function.cpp
* \brief 基础函数
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/

#include "travel_area_dect/common_function.h"

//找到点的位置对应的扇形序号
int FindIdx(double p_cos, double angle_cos[360]) {
  int num_real = -1;
  while (num_real < 359) {
    num_real++;
    if (angle_cos[num_real] > p_cos && p_cos > angle_cos[num_real + 1]) {
      break;
    }
  }
  return num_real;
}

//判断某图像位置是否在图像平面内
bool IsTrue(float u, float v, float u_max, float v_max) {
  if (u >= 0 && u < u_max && v >= 0 && v < v_max) {
    return true;
  } else {
    return false;
  }
}

//矩阵A(x*y)与矩阵B(y*z)的矩阵乘法函数
void MatrixMultiply(double a[], double b[], double c[], 
					          int x, int y, int z) {
  for (int i = 0; i < x; i++) {
    double *ptr_c = c + i * z;
    double *ptr_a = a + i * y;
    for (int j = 0; j < z; j++) {
      for (int k = 0; k < y; k++) {
        ptr_c[j] += ptr_a[k] * b[k * z + j];
      }
    }
  }
}

//二维矩阵转置函数
double *MatrixInver(double A[], int m, int n) {
  double *B = (double *)malloc(m * n * sizeof(double));
  if (B) {
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < m; j++) {
        B[i * m + j] = A[j * n + i];
      }
    }
  }
  return B;
}

//计算图像剪裁后的投影矩阵
void ProjectMatrixRenew(double camera_intrinsic_param[12],
                        double velo_camera_extrinsic_param[16], 
						            double dx, double dy, 
						            double P_velo_img[12]) {
  double temp_x = camera_intrinsic_param[2];
  camera_intrinsic_param[2] = temp_x - dx;
  double temp_y = camera_intrinsic_param[6];
  camera_intrinsic_param[6] = temp_y - dy;

  MatrixMultiply(camera_intrinsic_param, velo_camera_extrinsic_param,
                 P_velo_img, 3, 4, 4);
}

//对flag=2的点进行判断
void JudgeFlag2(float(*uv_xyz)[5], int *flag, vector<Point2f> points,
	Mat img, int is_show) {
	int(*birdmap)[int((Ymax - Ymin) / Birdpixel)];

	birdmap =
		new int[int((Xmax - Xmin) / Birdpixel)][int((Ymax - Ymin) / Birdpixel)];
	for (int i = 0; i < int((Xmax - Xmin) / Birdpixel); i++)
	for (int j = 0; j < int((Ymax - Ymin) / Birdpixel); j++) birdmap[i][j] = 0;
	for (size_t p_k = 0; p_k < points.size(); p_k++) {
		if (flag[p_k] == 1) {
			if (uv_xyz[p_k][2] >= Xmax || uv_xyz[p_k][2] <= Xmin ||
				uv_xyz[p_k][3] >= Ymax || uv_xyz[p_k][2] <= Ymin)
				continue;
			birdmap[int((Xmax - uv_xyz[p_k][2]) / Birdpixel) + 1]
				[int((uv_xyz[p_k][3] - Ymin) / Birdpixel) + 1] = 1;
		}
	}
	/*cout << int((Xmax - Xmin) / Birdpixel) << endl;
	cout << int((Ymax - Ymin) / Birdpixel) << endl;*/
	int x_max = int((Xmax - Xmin) / Birdpixel);
	int y_max = int((Ymax - Ymin) / Birdpixel);

	for (size_t p_k1 = 0; p_k1 < points.size(); p_k1++) {
		int nearby_flag = 0;
		if (flag[p_k1] == 2) {
			if (uv_xyz[p_k1][2] >= Xmax || uv_xyz[p_k1][2] <= Xmin ||
				uv_xyz[p_k1][3] >= Ymax || uv_xyz[p_k1][2] <= Ymin)
				flag[p_k1] = 0;
			else {
				int xx = round((uv_xyz[p_k1][2] - Xmin) / Birdpixel);
				int yy = round((uv_xyz[p_k1][3] - Ymin) / Birdpixel);

				int x_st = (0 > xx - 1 ? 0 : xx - 1);
				int x_ed = (x_max < xx + 1 ? x_max : xx + 1);
				int y_st = (0 > yy - 1 ? 0 : yy - 1);
				int y_ed = (y_max < yy + 1 ? y_max : yy + 1);

				for (int xx_i = x_st; xx_i < x_ed; xx_i++) {
					for (int yy_i = y_st; yy_i < y_ed; yy_i++) {
						nearby_flag = nearby_flag + birdmap[xx_i][yy_i];
					}
				}

				if (nearby_flag > 0)
					flag[p_k1] = 1;
				else
					flag[p_k1] = 0;
			}
		}
	}
    if (is_show == 1)
    {
    	for (size_t p_ID = 0; p_ID < points.size(); p_ID++)
    	{
		if ((uv_xyz[p_ID][4]) <= -1 )
            {
                if (flag[p_ID] == 1)
                    circle(img, points[p_ID], 1, Scalar(0, 0, 255), -1);
                else
                    circle(img, points[p_ID], 1, Scalar(255, 0, 0), -1);
            }
	    }
    }
	delete[] birdmap;
}

//画线函数
void MyLine(Mat img, Point start, Point end) {
  int thickness = 1;
  int lineType = 8;
  line(img, start, end, Scalar(0, 255, 0), thickness, lineType);
}
