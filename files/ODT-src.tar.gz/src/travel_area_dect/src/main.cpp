/*!
\mainpage 简介

本代码说明是机动车无人驾驶之可行驶区域检测系统的配套代码说明。本程序依赖ROS和PCL库。
本程序已在TX2 Ubuntu 16.04上测试通过。

\section Compelling

打开终端，启动roscore
~~~~~~~~~~~~~~~~~~~~~
roscore
~~~~~~~~~~~~~~~~~~~~~

另开一个终端
~~~~~~~~~~~~~~~~~~~~~
rosrun image_transport republish compressed in:=/camera/image_color raw out:=/camera/image_color
~~~~~~~~~~~~~~~~~~~~~

另开一个终端，编译代码
~~~~~~~~~~~~~~~~~~~~~
catkin_make
source ./devel/setup.bash
rosrun travel_area_dect DAdect_main
~~~~~~~~~~~~~~~~~~~~~

另开一个终端，播放数据集的rosbag：name.bag
~~~~~~~~~~~~~~~~~~~~~
rosbag play name.bag
~~~~~~~~~~~~~~~~~~~~~
即可得到可行驶区域结果

*/

/*!
* \file main.cpp
* \brief 主函数
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/
#include <ros/package.h>
#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <cv.h>
#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/image_encodings.h>

#include <camera_info_manager/camera_info_manager.h>
#include <image_transport/image_transport.h>

#include <pcl/common/transforms.h>
#include <pcl/conversions.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include <pcl_ros/impl/transforms.hpp>  

#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <message_filters/synchronizer.h>

#include "travel_area_dect/common_include.h"
#include "travel_area_dect/travel_area_dect.h"

using namespace message_filters;

Eigen::Matrix4f matrix_T = Eigen::Matrix4f::Identity();  
Eigen::Matrix4f matrix_R2M = Eigen::Matrix4f::Identity();  
Eigen::Matrix4f matrix_L2M = Eigen::Matrix4f::Identity();  

static std::unique_ptr<tf::TransformListener> g_tf_listener_left;
static std::unique_ptr<tf::TransformListener> g_tf_listener_right;

/** @arg 回调
 *	@param[in] msg_cam 相机图像
 * 	@param[in] ns1 右雷达
 * 	@param[in] ns2 左雷达
 * 	@param[in] ns3 中间雷达
 */
void CallbackTravelArea(const sensor_msgs::ImageConstPtr &msg_cam,
                        const sensor_msgs::PointCloud2::ConstPtr &ns1,
                        const sensor_msgs::PointCloud2::ConstPtr &ns2,
                        const sensor_msgs::PointCloud2::ConstPtr &ns3) {
  clock_t start2, finish2;
  double totaltime2;
  start2 = clock();
  // 获取点云
  pcl::PointCloud<pcl::PointXYZI>::Ptr scan1_(
      new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr scan2_(
      new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr scan3_(
      new pcl::PointCloud<pcl::PointXYZI>());

  pcl::PointCloud<pcl::PointXYZI>::Ptr scan1(
      new pcl::PointCloud<pcl::PointXYZI>());  //!< R
  pcl::PointCloud<pcl::PointXYZI>::Ptr scan2(
      new pcl::PointCloud<pcl::PointXYZI>());  //!< L
  pcl::PointCloud<pcl::PointXYZI>::Ptr scan3(
      new pcl::PointCloud<pcl::PointXYZI>());  //!< M

  pcl::fromROSMsg(*ns1, *scan1_);
  pcl::fromROSMsg(*ns2, *scan2_);
  pcl::fromROSMsg(*ns3, *scan3_);

  g_tf_listener_left->waitForTransform("velo_middle", ns2->header.frame_id,
                                       ns2->header.stamp, ros::Duration(5.0));
  pcl_ros::transformPointCloud("velo_middle", *scan2_, *scan2,
                               *g_tf_listener_left);

  g_tf_listener_right->waitForTransform("velo_middle", ns1->header.frame_id,
                                        ns1->header.stamp, ros::Duration(5.0));
  pcl_ros::transformPointCloud("velo_middle", *scan1_, *scan1,
                               *g_tf_listener_right);

  *scan3 = *scan3_;

  ROS_INFO_ONCE("travel_area_dect start");

  // 修正外参
  pcl::PointCloud<pcl::PointXYZI>::Ptr transformed_cloud1(
      new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr transformed_cloud2(
      new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr transformed_cloud3(
      new pcl::PointCloud<pcl::PointXYZI>());
  pcl::transformPointCloud(*scan1, *transformed_cloud1, matrix_R2M);
  pcl::transformPointCloud(*scan2, *transformed_cloud2, matrix_L2M);

  pcl::PointCloud<pcl::PointXYZI>::Ptr scan_(
      new pcl::PointCloud<pcl::PointXYZI>());  // 3个velo
  *scan_ = *transformed_cloud1 + *transformed_cloud2;
  *scan_ = *scan_ + *scan3;

  // 除nan点
  pcl::PointCloud<pcl::PointXYZI>::Ptr scan(
      new pcl::PointCloud<pcl::PointXYZI>());
  for (int i = 0; i < scan_->size(); i++) {
    if (pcl_isfinite(scan_->points[i].x)) { //只取非nan的值
      scan->points.push_back(scan_->points[i]);
    }
  }

  //在线读取点云数据，并进行减采样
  int subsample_factor = 1;
  int LINES = 100000 / subsample_factor;
  double(*lidar)[4];
  lidar = new double[LINES][4];  
  for (int i = 0; i < LINES; i++) {
    if (i < scan->size()) {
      lidar[i][0] = scan->points[i].x;
      lidar[i][1] = scan->points[i].y;
      lidar[i][2] = scan->points[i].z;
      lidar[i][3] = scan->points[i].intensity;
    } else {
      lidar[i][0] = 0.0;
      lidar[i][1] = 0.0;
      lidar[i][2] = 0.0;
      lidar[i][3] = 0.0;
    }
    if (isnan(lidar[i][0])) {
      lidar[i][0] = 0;
      lidar[i][1] = 0;
      lidar[i][2] = 0;
      lidar[i][3] = 0;
    }
  }

  // 读取RGB图像 //
  cv_bridge::CvImagePtr cv_ptr;
  try {
    cv_ptr = cv_bridge::toCvCopy(msg_cam, sensor_msgs::image_encodings::BGR8);
  } catch (cv_bridge::Exception &e) {
    ROS_ERROR("Not able to convert sensor_msgs::Image to OpenCV::Mat format %s",
              e.what());
    return;
  }
  cv::Mat I = cv_ptr->image;
  // 剪裁图像
  Mat img = I(Rect(imgX, imgY, imgWidth, imgHeight));
  Size size1 = img.size();

  finish2 = clock();

  clock_t start1;
  start1 = clock();

  // DAdect main //
  TravelAreaDect(LINES, lidar, img, size1);

  double finish_last = clock();
  double totaltime = (double)(finish_last - start1) / CLOCKS_PER_SEC;

  std::cout << "fps：" << 1.0 / totaltime << "帧" << endl;

}

int main(int argc, char **argv) {
  // 解析传入的ros参数，初始化节点的名称和其他信息
  ros::init(argc, argv, "travel_area_dect_node");  
  printf("Node successfully initialized. Ready to load data.\n");
  //（获取）节点句柄，用来创建Publisher、Subscriber和其他事情
  ros::NodeHandle node;  
  // pkg_loc = ros::package::getPath("travel_area_dect");
  image_transport::ImageTransport it(node);

/*
	// 常熟 矫正矩阵
	matrix_R2M<<0.999962617819078, 0.00113585215420984, 0.00857162786913699, 0.0205584108029520,
			   -0.000787917846807724, 0.999179789465142, -0.0404861397257171, 0.0776608277877785,
			   -0.00861058359868016, 0.0404778725269387, 0.999143332903661, 0.122889564522975,
			   0.0, 0.0, 0.0, 1.0;

	matrix_L2M<<0.999960648537247, -0.00689997820753617, -0.00557599118730402, 0.00465706998762154,
				0.00704254134754797, 0.999638031350889, 0.0259655326982781, -0.00719168137802936,
				0.00539481124354175, -0.0260037800650752, 0.999647287513954, 0.0117015507060637,
	*/			0.0, 0.0, 0.0, 1.0;
	
	// 学校 矫正矩阵
	matrix_R2M<<0.999998739425811, 0.000151320825182162, -0.00158058496216677, -0.00581075574335409,
			   -0.000167166413557331, 0.999949686063232, -0.0100298253959712, -0.0307238477751004,
			   0.00157898771525280, 0.0100300769733570, 0.999948450848244, -0.0115480915251211,
			   0.0, 0.0, 0.0, 1.0;

	matrix_L2M<<0.999991019222751, 0.000895310567647683, -0.00414245010200063, -0.00666738781484767,
			   -0.000868701443347249, 0.999979008675025, 0.00642086965557955, 0.0232127245030177,
			    0.00414811181894049, -0.00641721343879627, 0.999970805843872, 0.0495608661280785,
				0.0, 0.0, 0.0, 1.0;
	 

  g_tf_listener_left.reset(new tf::TransformListener());
  g_tf_listener_right.reset(new tf::TransformListener());
  // g_tf_listener_middle.reset(new tf::TransformListener());

  message_filters::Subscriber<sensor_msgs::PointCloud2> cloud_sub1(
      node, "/lidar/vlp16_right/PointCloud2", 5);
  message_filters::Subscriber<sensor_msgs::PointCloud2> cloud_sub2(
      node, "/lidar/vlp16_left/PointCloud2", 5);
  message_filters::Subscriber<sensor_msgs::PointCloud2> cloud_sub3(
      node, "/lidar/vlp32_middle/PointCloud2", 5);
  message_filters::Subscriber<sensor_msgs::Image> cam_sub(
      node, "/camera/image_color", 5);

  typedef sync_policies::ApproximateTime<sensor_msgs::Image, 
                                         sensor_msgs::PointCloud2, 
                                         sensor_msgs::PointCloud2,
                                         sensor_msgs::PointCloud2>MySyncPolicy1;
  Synchronizer<MySyncPolicy1> sync(MySyncPolicy1(10), cam_sub, cloud_sub1,
                                   cloud_sub2, cloud_sub3);
  sync.registerCallback(boost::bind(&CallbackTravelArea, _1, _2, _3, _4));
  ros::spin();  //回旋

  return 0;
}
