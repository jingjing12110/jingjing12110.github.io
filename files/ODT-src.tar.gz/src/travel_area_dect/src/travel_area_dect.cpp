﻿/*!
* \file travel_area_dect.cpp
* \brief 可行驶区域检测相关函数
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/

#include "travel_area_dect/travel_area_dect.h"

int savenum = 0;// 1000000;

//  学校
// /// 内参数矩阵
// double camera_intrinsic_param[12] = {
//     773.5120, 0, 713.5189, 0, 0, 775.9696, 265.4049, 0, 0, 0, 1.0000, 0,
// };

// /// 外参数矩阵
// double velo_camera_extrinsic_param[16]{0.0151,  -0.9999, -0.0060, -0.0616,
//                                        -0.0313, 0.0056,  -0.9995, -0.3165,
//                                        0.9994,  0.0153,  -0.0312, -0.0706};
// 


// 常熟
// 内参数矩阵
double camera_intrinsic_param[12] = { 773.5120, 0, 713.5189, 0,
    0, 775.9696, 265.4049, 0,
    0, 0, 1.0000, 0,
};

// 外参数矩阵
double velo_camera_extrinsic_param[16]{ 0.0009, -1, -0.0084, -0.0687,
	-0.0238, 0.0084, -0.9997, -0.2373,
	0.9997, 0.0011, -0.0238, -0.1218,
	0, 0, 0, 1
};

// 投影矩阵的声明
double P_velo_to_img[12] = {0.0};

/**
 * @brief 数据查找表

 详细说明：计算出图像中每个坐标对应的距离、对应的区间（bin）等反复使用的中间数据，放入查找表中，以避免重复计算，达到提速的效果
 */
struct DataTable {
    double pixel_dist[imgHeight][imgWidth];  ///< 每个像素位置距离图像底边中点的距离
    double idx_offline[imgHeight][imgWidth]; ///< 每个像素位置属于的区域（bin）编号
    double pixel_dist_max[360];  ///< 每个bin里面由消失点约束的最大距离可行驶距离
    /// 初始化时计算出查找表
	DataTable() {
    clock_t start00 = clock();
	
    double pixel_cos[imgHeight][imgWidth];
    double angle_cos_table[360];
    pixel_dist_max[360] = {0};  // 每个bin里面最大距离
    for (int i = 0; i < 360; i++) {
      angle_cos_table[i] = cos((i * 0.5) / 57.2958);
    }

    int img_col = imgHeight;
    int img_row = imgWidth;

    for (int i = 0; i < img_col; i++) {
      for (int j = 0; j < img_row; j++) {
        pixel_dist[i][j] =
            sqrt(pow(i - img_col, 2) + pow(j - img_row / 2.0, 2));
        pixel_cos[i][j] = -(j - img_row / 2.0) / (pixel_dist[i][j] + 0.000001);
      }
    }

    int idx;
    for (int i = 0; i < img_col; i++) {
      for (int j = 0; j < img_row; j++) {
        idx = FindIdx(pixel_cos[i][j], angle_cos_table);
        idx_offline[i][j] = idx;
      }
    }

	// 计算pixel_dist_max
	ProjectMatrixRenew(camera_intrinsic_param,
		velo_camera_extrinsic_param, imgX,
		imgY, P_velo_to_img);
	Mat init(imgHeight, imgWidth, CV_8UC1, Scalar(0));

	double k = 0;
	int vLimit = 0;
	for (int j = 0; j < imgWidth; j++) {
		k = (j * P_velo_to_img[8] - P_velo_to_img[0]) / (P_velo_to_img[1] - j * P_velo_to_img[9]);
		vLimit = (int)((P_velo_to_img[4] + k * P_velo_to_img[5]) / (P_velo_to_img[8] + k * P_velo_to_img[9]));
		for (int i = 0; i < vLimit; i++) {
			init.ptr<uchar>(i)[j] = 255;
		}
	}

	//string path;
	//path = "C:\\Users\\hp\\Desktop\\test.jpg";
	//cv::imwrite(path, init);

    for (int i = 0; i < img_col; i++){
      for (int j = 0; j < img_row; j++) {
        if ((int)init.at<uchar>(i, j) == 0 &&
            pixel_dist[i][j] >
                pixel_dist_max[(int)floor(idx_offline[i][j])]) {
          pixel_dist_max[(int)floor(idx_offline[i][j])] = pixel_dist[i][j];
        }
      }
   }
   
   clock_t finish00 = clock();
   double totaltime00 = (double)(finish00 - start00) / CLOCKS_PER_SEC;
   printf("Data Table Initialized.\n");
   if (silence == 0){
	   printf("查找表计算时间: %f\n", totaltime00);
   }
  }

} dTab;  // 全局变量;

/**
 * @brief 计算每个扇形区域的可行驶区域的长度
 * @param[in] num_real 实际使用的点的数量
 * @param[in] uv_xyz 点云及其投影
 * @param[in] size1 图像长宽
 * @param[out] VBD 结构体，保存扇形区域的序号与可行驶区域的长度
 */
void CalculateVeloBD(int num_real, float (*uv_xyz)[5], Size size1, VeloBD VBD) {
  // 1.得到变量bin_index,bin_index[i]表示第i个点在哪个图像区域
  for (int i = 0; i < num_real; i++) {
    int m = (int)uv_xyz[i][0];
    int n = (int)uv_xyz[i][1];
    if (!IsTrue(m, n, size1.width, size1.height)) { //如果不在图像坐标内
      VBD.bin_index[i] = -1;
    } else {
      int idx = dTab.idx_offline[n][m];
      VBD.bin_index[i] = idx;
    }
  }

  // 2、对于每个激光点计算相对于基点的距离，uv_dist[num_real]
  // int  *dist;  dist = new int[num_real];
  for (int pi = 0; pi < num_real; pi++) {
    int u = int(uv_xyz[pi][0]);
    int v = int(uv_xyz[pi][1]);
    if (!IsTrue(u, v, size1.width, size1.height)) { //如果不在图像坐标内
      VBD.dist[pi] = 999999;
    } else {
      VBD.dist[pi] = dTab.pixel_dist[v][u];
    }
  }
}

/**
 * @brief 根据障碍物分类结果得到每个角度区域内的最远可行驶区域位置
 * @details 获得障碍物分类结果以后，首先将图像以底边中点为中心，按照角度平均,细分为num_bin个扇形区域；
 然后，对每个区域得到最近的障碍物点或最远的非障碍物点（p0_set）；
 最后，对p0_set进行滤波以改善泄露问题。得到最后输出（p0_set_order_min）。
 * @param[in] num_bin 细分区域个数
 * @param[in] window_len 滤波窗口大小
 * @param[in] num_real 实际使用的点的数量
 * @param[in] size1 图像长宽
 * @param[in] uv_xyz 雷达点的图像和空间坐标
 * @param[in] vBD VeloBD结构体
 * @param[in] flag 雷达点障碍物分类结果
 * @param[in] base_pt 图像底边中点位置
 * @param[out] p0_set 每个角度区域内的最远可行驶区域位置（滤波前）
 * @param[out] p0_set_order_min 每个角度区域内的最远可行驶区域位置（滤波后）
 */
void CalculateP0BaseSet(int num_bin, int window_len, int num_real, Size size1,
                        float (*uv_xyz)[5], VeloBD vBD, int *flag,
						Mat p0_set_order_min, Point base_pt, Mat p0_set) {
  //初始化
  // Mat p0_set(4, num_bin, CV_32FC1, Scalar(20000));//0对应u，1对应v，2对应距离，3对应标志位
  Mat p0_set_order(3, num_bin, CV_32FC1);

  //对每个雷达点循环
  for (int bin_num_col_i = 0; bin_num_col_i < num_real; bin_num_col_i++) {
    if (IsTrue(uv_xyz[bin_num_col_i][0], uv_xyz[bin_num_col_i][1], size1.width,
               size1.height)) { //如果点在图像坐标中
      int bin_P = vBD.bin_index[bin_num_col_i];//该点所在的bin编号
      if (bin_P < 0) {
      // 用于调试
      //cout << (int)uv_xyz[bin_num_col_i][0] << endl;
      //cout << (int)uv_xyz[bin_num_col_i][1] << endl;
        continue;
      }
      if (flag[bin_num_col_i] == 1) { //如果是障碍点
        p0_set.ptr<float>(3)[bin_P] = 1;  //标志位，表示这个bin里面有障碍点
        if (vBD.dist[bin_num_col_i] < p0_set.ptr<float>(2)[bin_P]) {
          //如果该障碍物点为当前bin内最近的障碍物点，则保存其位置与距离
          p0_set.ptr<float>(0)[bin_P] = uv_xyz[bin_num_col_i][0];
          p0_set.ptr<float>(1)[bin_P] = uv_xyz[bin_num_col_i][1];
          p0_set.ptr<float>(2)[bin_P] = vBD.dist[bin_num_col_i];
        }
      }
    }
  }

  for (int bin_num_i = 0; bin_num_i < num_bin; bin_num_i++) {
    if (p0_set.ptr<float>(3)[bin_num_i] == 10 ||
        p0_set.ptr<float>(3)[bin_num_i] == 1) {
      continue;
    }
	//没有障碍物点的bin，，距离设为0，标志位设为0
    p0_set.ptr<float>(3)[bin_num_i] = 0;//标志位
    p0_set.ptr<float>(2)[bin_num_i] = 0;//距离
  }

  //得到p0_set
  for (int bin_num_col_i = 0; bin_num_col_i < num_real; bin_num_col_i++) {
    if (IsTrue(uv_xyz[bin_num_col_i][0], uv_xyz[bin_num_col_i][1], size1.width,
               size1.height)) { //如果点在图像坐标中
      float temp1 = p0_set.ptr<float>(3)[0];
      int bin_P = vBD.bin_index[bin_num_col_i];  //这个点属于第几个bin
      if ((int)p0_set.ptr<float>(3)[bin_P] == 10 ||
          (int)p0_set.ptr<float>(3)[bin_P] == 1) {
        continue;
      }
      if (flag[bin_num_col_i] == 0) { //如果不是障碍点
        if (vBD.dist[bin_num_col_i] > p0_set.ptr<float>(2)[bin_P]) {
          p0_set.ptr<float>(0)[bin_P] = uv_xyz[bin_num_col_i][0];
          p0_set.ptr<float>(1)[bin_P] = uv_xyz[bin_num_col_i][1];
          p0_set.ptr<float>(2)[bin_P] = vBD.dist[bin_num_col_i];
        }
      }
      //if (temp1 != p0_set.ptr<float>(3)[0]) int a = 1;
    }
  }

  delete[] uv_xyz;
  delete[] vBD.bin_index;
  delete[] vBD.dist;
  delete[] flag;

  //用p0_set初始化p0_set_order_dist，将无障碍物点的bin，对应的距离设为极大值，以避免其影响最小值的计算
  float p0_set_order_dist[360];
  for (int i = 0; i < num_bin; i++) {
    p0_set_order_min.ptr<float>(3)[i] = p0_set.ptr<float>(3)[i];
    if ((int)p0_set.ptr<float>(3)[i] == 0) {
      p0_set_order.ptr<float>(0)[i] = p0_set.ptr<float>(0)[i];
      p0_set_order.ptr<float>(1)[i] = p0_set.ptr<float>(1)[i];
      p0_set_order.ptr<float>(2)[i] = 99999; //将无障碍物点的bin，对应的距离设为极大值，以避免其影响最小值的计算
    } else {
      p0_set_order.ptr<float>(0)[i] = p0_set.ptr<float>(0)[i];
      p0_set_order.ptr<float>(1)[i] = p0_set.ptr<float>(1)[i];
      p0_set_order.ptr<float>(2)[i] = p0_set.ptr<float>(2)[i];
    }
  }
  float min_temp = 10000;
  float max_temp;
  int st_line, en_line;
  for (int i = 0; i < num_bin; i++) {  //对于每个bin
    bool no_min_flag = false;
    float temp = 0;
    if ((int)p0_set.ptr<float>(3)[i] == 0)  //如果该bin没有障碍物点
    {
      no_min_flag = true;
    }
    //确定该bin的邻域边界
    if (i - window_len / 2 < 0)
      st_line = 0;
    else
      st_line = i - window_len / 2;
    if (i + window_len / 2 > num_bin)
      en_line = num_bin;
    else
      en_line = i + window_len / 2;

    Mat temp_window_flag = p0_set.colRange(st_line, en_line).clone();
    Mat temp_window_flag2 = temp_window_flag.rowRange(3, 4).clone();
    max_temp = *max_element(temp_window_flag2.begin<float>(),
                            temp_window_flag2.end<float>());

    if (max_temp == 0) { //表示整个邻域窗口都是没有障碍物的区域，进行最大值滤波
      Mat temp_window = p0_set.colRange(st_line, en_line).clone();
      Mat temp_window2 = temp_window.rowRange(2, 3).clone();
      min_temp =
          *max_element(temp_window2.begin<float>(), temp_window2.end<float>());
      p0_set_order_min.ptr<float>(2)[i] = min_temp;
      p0_set_order_dist[i] = min_temp;
      float shrink_rate = p0_set.ptr<float>(2)[i] / min_temp;
      float shrink_rate2 = shrink_rate;

      float i_temp =
          (p0_set_order.ptr<float>(1)[i] - base_pt.y) / shrink_rate + base_pt.y;
      float j_temp =
          (p0_set_order.ptr<float>(0)[i] - base_pt.x) / shrink_rate + base_pt.x;

      if (i_temp < 0) i_temp = 0;
      if (i_temp >= size1.height) i_temp = size1.height - 1;
      if (j_temp < 0) j_temp = 0;
      if (j_temp >= size1.width) j_temp = size1.width - 1;

      p0_set_order_min.ptr<float>(0)[i] = j_temp;
      p0_set_order_min.ptr<float>(1)[i] = i_temp;
      p0_set_order_min.ptr<float>(2)[i] =
          dTab.pixel_dist[(int)i_temp][(int)j_temp];
    } else {  //表示邻域窗口中包含障碍物，进行最小值滤波
      Mat temp_window = p0_set_order.colRange(st_line, en_line).clone();
      Mat temp_window2 = temp_window.rowRange(2, 3).clone();
      min_temp =
          *min_element(temp_window2.begin<float>(), temp_window2.end<float>());

      p0_set_order_min.ptr<float>(2)[i] = min_temp;
      p0_set_order_dist[i] = min_temp;

      float shrink_rate = p0_set.ptr<float>(2)[i] / min_temp;
      float shrink_rate2 = shrink_rate;
      if (shrink_rate2 > 1) {
        shrink_rate2 = 1;
        int a = 1;
      }
      float i_temp =
          (p0_set_order.ptr<float>(1)[i] - base_pt.y) / shrink_rate + base_pt.y;
      float j_temp =
          (p0_set_order.ptr<float>(0)[i] - base_pt.x) / shrink_rate + base_pt.x;

      if (i_temp < 0) i_temp = 0;
      if (i_temp >= size1.height) i_temp = size1.height - 1;
      if (j_temp < 0) j_temp = 0;
      if (j_temp >= size1.width) j_temp = size1.width - 1;

      p0_set_order_min.ptr<float>(0)[i] = j_temp;
      p0_set_order_min.ptr<float>(1)[i] = i_temp;
      p0_set_order_min.ptr<float>(2)[i] =
          dTab.pixel_dist[(int)i_temp][(int)j_temp];
    }
  }

  //不可以超过由相机内参确定的最大值
  for (int beam_i = 0; beam_i < num_bin; beam_i++) {
    if (IsTrue(p0_set_order_min.ptr<float>(0)[beam_i],
               p0_set_order_min.ptr<float>(1)[beam_i], 
			   size1.width,
               size1.height)) {
      float dx = p0_set_order_min.ptr<float>(0)[beam_i] - base_pt.x;
      float dy = p0_set_order_min.ptr<float>(1)[beam_i] - base_pt.y;
      float dl = sqrt(dx * dx + dy * dy);

      float max = dTab.pixel_dist_max[beam_i];

      if (dl > dTab.pixel_dist_max[beam_i]) {
        dx = dx * max / dl;
        dy = dy * max / dl;
        p0_set_order_min.ptr<float>(0)[beam_i] = dx + base_pt.x;
        p0_set_order_min.ptr<float>(1)[beam_i] = dy + base_pt.y;
		p0_set_order_min.ptr<float>(2)[beam_i] = max;
      }
    }
  }
}

/**
 * @brief 检测结果可视化
 * @param[in] num_bin 扇形区域数目
 * @param[in] p0_set_order_min 包含每个区域最远可行驶位置的点集
 * @param[in] base_pt 线的起点坐标，默认为图像最下方中间的位置
 * @param[in] img 原始图像
 */
void ShowDrivingArea(int num_bin, 
					 Mat p0_set_order_min, 
					 Point base_pt,
                     Mat img) {

  // string s0 ;
  // = to_string(savenum);
  // s1[0] = 0;
  //s0 = "/home/yz/Pictures/wutong0/"+ to_string(savenum) + ".png";
  //cv::imwrite(s0, img);

  Mat outputImage = Mat::zeros(img.rows, img.cols, CV_8UC1);
  Size size1 = img.size();
  for (int beam_i = 0; beam_i < num_bin; beam_i++) {
    //testi = 0;
    bool tt = IsTrue(p0_set_order_min.ptr<float>(0)[beam_i],
                     p0_set_order_min.ptr<float>(1)[beam_i], 
					           size1.width, size1.height);
    if (IsTrue(p0_set_order_min.ptr<float>(0)[beam_i],
               p0_set_order_min.ptr<float>(1)[beam_i], 
			         size1.width, size1.height)) {
        MyLine(img, base_pt,
               Point((int)p0_set_order_min.ptr<float>(0)[beam_i],
               (int)p0_set_order_min.ptr<float>(1)[beam_i]));  //划线
    }
  }
  
  imshow("img2", img);

  int rowNumber = outputImage.rows;  //行数
  int colNumber = outputImage.cols;  //列数 x 通道数=每一行元素的个数
  //双重循环，遍历所有的像素值
  int p_gray = 0;
  float p_cos_current = 0;

  for (int i = 180; i < rowNumber; i++) {
    uchar *data = outputImage.ptr<uchar>(i);  //获取第i行的首地址

    for (int j = 0; j < colNumber; j++) {
      int idx = dTab.idx_offline[i][j];
      if (dTab.pixel_dist[i][j] > p0_set_order_min.ptr<float>(2)[idx])
        data[j] = 0;
      else
        data[j] = 255;
    }
  }  //行处理结束

  //imshow("img1", outputImage);
  waitKey(1);
  if (save_res == 1)
  {
  string s0;
  s0 = "/home/nvidia/result/filter/" + cv::format("%.8d", savenum) + ".jpg";
  cv::imwrite(s0, img);

  string s1;
  s1 = "/home/nvidia/result/bin/" + cv::format("%.8d", savenum) + ".jpg";
  cv::imwrite(s1, outputImage);

  savenum++;
  }
}

/**
 * @brief 可行驶区域检测

 详细说明：本函数为可行驶区域检测的主体函数，主要流程为：点云投影->三角剖分建立->障碍物判断->得到可行驶区域->滤波优化可行驶区域结果
 * @param[in] LINES 实际使用到的点数量
 * @param[in] lidar 点云数据
 * @param[in] img 图像
 * @param[in] size1 图像的大小
 */
void TravelAreaDect(int LINES, double (*lidar)[4], Mat img, Size size1) {
  // 根据可能的主点变化调整投影矩阵，在初始化查找表的时候已经完成
  /*ProjectMatrixRenew(camera_intrinsic_param,
  					         velo_camera_extrinsic_param, imgX,
                     imgY, P_velo_to_img);*/
  //点云投影到图像
  clock_t start01 = clock();
  ProcessVeloData pVD_org = ProjectVelo2Img(LINES, lidar, P_velo_to_img, size1);
  clock_t finish01 = clock();
  
 
  clock_t start02 = clock(); 
  ProcessVeloData pVD_org2 = DeleteDuplicatePoints(pVD_org);
  delete[] pVD_org.uv_xyz;
  ProcessVeloData pVD = Downsampling(pVD_org2);
  delete[] pVD_org2.uv_xyz;
  clock_t finish02 = clock();
 


  // 2D三角剖分
  clock_t start03 = clock();
  int num_real = pVD.size_velo2img;
  vector<Point2f> points;  //得到三角剖分的点集(u,v)
  for (int i = 0; i < num_real; i++) {
    float u = float(pVD.uv_xyz[i][0]);
    float v = float(pVD.uv_xyz[i][1]);
    points.push_back(Point2f(u, v));
  }

  Rect rect(0, 0, size1.width + WidthAdd, size1.height + HighAdd);
  Subdiv2D subdiv(rect);
  for (size_t ii = 0; ii < points.size(); ii++) {
    subdiv.insert(points[ii]);  //必须保证所有插入的2D点均在图像平面内。
  }
  clock_t finish03 = clock();

  //计算三角剖分法向量，判断雷达点是否是障碍物
  clock_t start04 = clock();
  int *flag;
  flag = new int[num_real];
  Threshold thr;
  NormalTriangulation(pVD.uv_xyz, thr, points, subdiv, 
  					          img, flag, plot_point);  //计算法向量
  clock_t finish04 = clock();

  
  //利用邻域信息进一步判断雷达点是否是障碍物
  clock_t start05 = clock(); 
  JudgeFlag2(pVD.uv_xyz, flag, points, img, plot_point);
  clock_t finish05 = clock();

  //imshow("result", img);
  //cv::imwrite((publicPath + obsFile + imageName + imgEnd).c_str(), img);	 // 保存障碍物点检测结果

  VeloBD vBD;
  vBD.bin_index = new int[num_real];
  vBD.dist = new int[num_real];

  CalculateVeloBD(num_real, pVD.uv_xyz, size1, vBD);

  int num_bin = 360;
  int window_len = num_bin / 45;  //探测线参数
  Mat p0_set_order_min(4, num_bin, CV_32FC1);
  Mat p0_set(4, num_bin, CV_32FC1, Scalar(20000)); //未滤波的结果，4维中0对应u，1对应v，2对应距离，3对应标志位
  Point base_pt = Point(int(img.cols / 2) - 1, int(img.rows) - 1);

  //求p0_set并进行最大最小值滤波
  clock_t start06 = clock();
  CalculateP0BaseSet(num_bin, window_len, num_real, size1, 
  					         pVD.uv_xyz, vBD, flag, 
							 p0_set_order_min, base_pt, p0_set);
  clock_t finish06 = clock();


  //结果表示-可视化可行驶区域
  clock_t start07 = clock();
  ShowDrivingArea(num_bin, p0_set_order_min, base_pt, img);
  //ShowDrivingAreaBefore(num_bin, p0_set, base_pt, img, imageName);
  clock_t finish07 = clock();

 
  if (silence == 0) {
  double totaltime01 = (double)(finish01 - start01) / CLOCKS_PER_SEC;
  double totaltime02 = (double)(finish02 - start02) / CLOCKS_PER_SEC;
  double totaltime03 = (double)(finish03 - start03) / CLOCKS_PER_SEC;
  double totaltime04 = (double)(finish04 - start04) / CLOCKS_PER_SEC;
  double totaltime05 = (double)(finish05 - start05) / CLOCKS_PER_SEC;
  double totaltime06 = (double)(finish06 - start06) / CLOCKS_PER_SEC;
  double totaltime07 = (double)(finish07 - start07) / CLOCKS_PER_SEC;
  printf("数据融合的时间: %f\n", totaltime01);
  printf("稀疏化的时间: %f\n", totaltime02);
  printf("三角剖分的时间: %f\n", totaltime03);
  printf("计算法向量的时间: %f\n", totaltime04);
  printf("判断类型点的时间: %f\n", totaltime05);
  printf("最大最小值滤波的时间: %f\n", totaltime06);
  printf("可视化与保存结果的时间: %f\n", totaltime07);
  }
  
}
