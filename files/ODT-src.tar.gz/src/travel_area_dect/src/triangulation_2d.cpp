﻿/*!
* \file triangulation_2d.cpp
* \brief 三角剖分相关函数
* \author 西安交通大学人工智能与机器人研究所
* \version V1.0
* \date 2019-05-10
*/
#include "travel_area_dect/triangulation_2d.h"

// 点云在图像平面上的像素表达
ProcessVeloData ProjectVelo2Img(int LINES, double (*lidar)[4],
                                double P_velo_to_img[12], Size size1) {
  //点云数据预处理
  int k_xyz = 0;
  for (int i = 0; i < LINES; i++) {
    if (lidar[i][0] >= 3 & lidar[i][2] < 1) {          // 除去不感兴趣点；
      k_xyz++;
    }
  }
  if (silence == 0){
  cout << " 点的数量=" << k_xyz << endl;
  }
  double(*p_in)[4];
  p_in = new double[k_xyz][4];
  int kk_xyz = 0;
  for (int i = 0; i < LINES; i++) {
    if (lidar[i][0] >= 3 & lidar[i][2] < 1) {
      p_in[kk_xyz][0] = lidar[i][0];  // x坐标
      p_in[kk_xyz][1] = lidar[i][1];  // y坐标
      p_in[kk_xyz][2] = lidar[i][2];  // z坐标
      p_in[kk_xyz][3] = 1.0;          // 齐次坐标 1
      kk_xyz++;
    }
  }
  delete[] lidar;

  //在图像上展示激光点
  //for (int a = 0; a < kk_xyz; a++) {
	 // Point p;
	 // p.x = (int)p_in[a][1];
	 // p.y = (int)p_in[a][0];
	 // circle(img, p, 1, Scalar(0, 0, 255), -1);
  //}
  //string ss;
  //ss = "C:\\Users\\hp\\Desktop\\test\\project.jpg";
  //cv::imwrite(ss, img);

  //矩阵转置
  double *result;
  result = MatrixInver((double *)p_in, k_xyz, 4);

  // 投影变换，矩阵相乘
  double *img0;
  img0 = new double[3 * k_xyz];
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < k_xyz; j++) {
      double temp1 = 0.0;
      for (int k = 0; k < 4; k++) {
        temp1 += P_velo_to_img[4 * i + k] * result[k_xyz * k + j];
      }
      img0[k_xyz * i + j] = temp1;
    }
  }
  delete[] result;

  for (int j = 0; j < k_xyz; j++) {
    img0[j] = img0[j] / img0[2 * k_xyz + j];
    img0[k_xyz + j] = img0[k_xyz + j] / img0[2 * k_xyz + j];
    img0[2 * k_xyz + j] = 1.0;
  }

  float(*velo_img)[5];
  velo_img = new float[k_xyz][5];  // u,v,x,y,z 五列数据
  int number_in_rect = 0;
  for (int i = 0; i < k_xyz; i++) {
    velo_img[i][0] = img0[i];
    velo_img[i][1] = img0[k_xyz + i];
    if (IsTrue(velo_img[i][0], velo_img[i][1], size1.width + WidthAdd,
               size1.height + HighAdd)) {
      number_in_rect++;
    }
    velo_img[i][2] = p_in[i][0];  // 3D:x坐标
    velo_img[i][3] = p_in[i][1];  // 3D:y坐标
    velo_img[i][4] = p_in[i][2];  // 3D:z坐标
  }
  delete[] img0;
  delete[] p_in;

  // velo_img为nx5的数组；保证所有velo-img均在图像矩形范围内，计算三角剖分。
  float(*uv_xyz)[5];
  uv_xyz = new float[number_in_rect][5];  // u,v,x,y,z 五维数据
  int num_real = 0;
  for (int i = 0; i < k_xyz; i++) {
	  if (IsTrue(velo_img[i][0], velo_img[i][1], size1.width + WidthAdd,
		  size1.height + HighAdd)) {
      uv_xyz[num_real][0] = velo_img[i][0];
      uv_xyz[num_real][1] = velo_img[i][1];
      uv_xyz[num_real][2] = velo_img[i][2];
      uv_xyz[num_real][3] = velo_img[i][3];
      uv_xyz[num_real][4] = velo_img[i][4];
      num_real++;
    }
  }
  delete[] velo_img;

  ProcessVeloData pVD;
  pVD.size_velo2img = num_real;
  pVD.uv_xyz = uv_xyz;
  return pVD;
}

//稀疏化减采样
ProcessVeloData Downsampling(ProcessVeloData pVD_org) {
  int occupy_flag[imgHeight][imgWidth] = {0};
  const int num_real = pVD_org.size_velo2img;
  bool(*pVD_flag) = new bool[num_real];
  for (int i = 0; i < num_real; i++) pVD_flag[i] = 0;
  double sparse_subsample_rate = 5;
  int x_, y_;
  int x_st, y_st, x_ed, y_ed;
  int numberC = 0;
  for (int i = 0; i < num_real; i++) {
    x_ = pVD_org.uv_xyz[i][1];
    y_ = pVD_org.uv_xyz[i][0];
    if (!(pVD_org.uv_xyz[i][4] > -3.0 && pVD_org.uv_xyz[i][4] < -1.7) ||
        (x_ > imgHeight || x_ <= 1.0) || (y_ > imgWidth || y_ < 1.0) ||
        pVD_org.uv_xyz[i][2] > 40.0) 
	{
      pVD_flag[i] = 1;
    } else {
      x_ = round(x_);
      y_ = round(y_);
      x_st = max(1.0, x_ - sparse_subsample_rate);
      x_ed = min(double(imgHeight), x_ + sparse_subsample_rate);
      y_st = max(1.0, y_ - sparse_subsample_rate);
      y_ed = min(double(imgWidth), y_ + sparse_subsample_rate);
      if (occupy_flag[x_ - 1][y_ - 1] == 0) {
        for (int xx = x_st - 1; xx < x_ed; xx++) {
          for (int yy = y_st - 1; yy < y_ed; yy++) {
            occupy_flag[xx][yy] = 1;
            pVD_flag[i] = 1;
          }
        }
      }
    }
  }

  for (int i = 0; i < num_real; i++) {
    if (pVD_flag[i] == 1) numberC++;
  }

  float(*uv_xyz)[5];
  uv_xyz = new float[numberC][5];
  int numberC1 = 0;
  for (int i = 0; i < num_real; i++) {
    if (pVD_flag[i] == 1) {
      uv_xyz[numberC1][0] = pVD_org.uv_xyz[i][0];
      uv_xyz[numberC1][1] = pVD_org.uv_xyz[i][1];
      uv_xyz[numberC1][2] = pVD_org.uv_xyz[i][2];
      uv_xyz[numberC1][3] = pVD_org.uv_xyz[i][3];
      uv_xyz[numberC1][4] = pVD_org.uv_xyz[i][4];
      numberC1++;
    }
  }

  delete[] pVD_flag; //删除
  ProcessVeloData pVD;
  pVD.uv_xyz = uv_xyz;
  pVD.size_velo2img = numberC1;
  return pVD;
}

//删除重复的点(否则三角剖分出问题)
ProcessVeloData DeleteDuplicatePoints(ProcessVeloData pVD_org)
{
	bool(*flag_repeat)[imgHeight + HighAdd]; flag_repeat = new bool[imgWidth + WidthAdd][imgHeight + HighAdd];
	for (int i = 0; i < imgWidth + WidthAdd; i++)
	for (int j = 0; j < imgHeight + HighAdd; j++)
		flag_repeat[i][j] = false;
	//memset(flag_repeat, false, sizeof(bool));
	bool(*flag_repeat1)[imgHeight + HighAdd]; flag_repeat1 = new bool[imgWidth+ WidthAdd][imgHeight + HighAdd];
	for (int i = 0; i < imgWidth + WidthAdd; i++)
	for (int j = 0; j < imgHeight + HighAdd; j++)
		flag_repeat1[i][j] = false;


	int num_real = pVD_org.size_velo2img;

	int numberC = 0;

	for (int i = 0; i <num_real; i++)
	{
		float  u = float(pVD_org.uv_xyz[i][0]);
		float  v = float(pVD_org.uv_xyz[i][1]);
		//cout << "v:"<<(int)v <<"u:"<< (int)u <<"flag="<< flag_repeat[(int)v][(int)u] << endl;
		if (flag_repeat[(int)(u)][(int)(v)]) continue;

		else{
			numberC++;
			flag_repeat[(int)(u)][(int)(v)] = true;
		}

	}
        delete[] flag_repeat;
	//std::cout << "numberC=" << numberC << endl;

	float(*uv_xyz)[5];    uv_xyz = new float[numberC][5];      //u,v,x,y,z 五维数据
	int numberC1 = 0;
	for (int j = 0; j < num_real; j++)
	{
		float  u = float(pVD_org.uv_xyz[j][0]);
		float  v = float(pVD_org.uv_xyz[j][1]);

		if (flag_repeat1[(int)(u)][(int)(v)]) continue;
		//points.push_back(Point2f(u, v));
		else{

		uv_xyz[numberC1][0] = pVD_org.uv_xyz[j][0];
		uv_xyz[numberC1][1] = pVD_org.uv_xyz[j][1];
		uv_xyz[numberC1][2] = pVD_org.uv_xyz[j][2];
		uv_xyz[numberC1][3] = pVD_org.uv_xyz[j][3];
		uv_xyz[numberC1][4] = pVD_org.uv_xyz[j][4];
		numberC1++;
		flag_repeat1[(int)(u)][(int)(v)] = true;
		}
	}
	
	delete[] flag_repeat1;
	//std::cout << "numberC1=" << numberC1 << endl;
	ProcessVeloData pVD;
	pVD.uv_xyz = uv_xyz;
	pVD.size_velo2img = numberC;
	// delete[] uv_xyz;

	return pVD;

}

//求三角形的法向量(返回余弦的平方)
double Normal(double A_x, double A_y, double A_z, double B_x, double B_y,
              double B_z, double C_x, double C_y, double C_z, double tri) {
  double ab_x = B_x - A_x;
  double ab_y = B_y - A_y;
  double ab_z = B_z - A_z;

  double ac_x = C_x - A_x;
  double ac_y = C_y - A_y;
  double ac_z = C_z - A_z;

  double normal_x = ab_y * ac_z - ab_z * ac_y;
  double normal_y = -(ab_x * ac_z - ac_x * ab_z);
  double normal_z = ab_x * ac_y - ac_x * ab_y;

  tri = (pow(normal_x, 2) + pow(normal_y, 2)) /
        (pow(normal_x, 2) + pow(normal_y, 2) + pow(normal_z, 2));
  return tri;
}

//求三角剖分结果的法向量
void NormalTriangulation(float (*uv_xyz)[5], Threshold thr,
                         vector<Point2f> points, Subdiv2D subdiv, Mat img,
                         int *flag, int is_show) {
  
 // printf("points.size = %d\n", points.size());

  for (size_t p_ID = 0; p_ID < points.size(); p_ID++) {
    if ((uv_xyz[p_ID][4]) > -1 || p_ID > 33000) 
      flag[p_ID] = 1;
    else {
      int el = 1;
      int *firstEdge = &el;
      //得到p_ID点的源边ID，firstedge为返回参数
      subdiv.getVertex(p_ID + 4, firstEdge);

      int nowEdge_ID = *firstEdge;

      //初始化
      double tri_sum = 0;
      double tri_average = 0;
      int counter = 0;

      while (1) {
        int nextEdge_ID =
            subdiv.getEdge(nowEdge_ID, Subdiv2D::PREV_AROUND_ORG);  //逆时针转

        // nowEdge像素边长
        int P_org_ID = p_ID + 4;
        int P_now_dst_ID = subdiv.edgeDst(nowEdge_ID);  //点ID
        vector<Point2f> PT_now_uv(2);
        PT_now_uv[0] = subdiv.getVertex(P_org_ID);  // PT为 边两端的坐标
        PT_now_uv[1] = subdiv.getVertex(P_now_dst_ID);
        double d2_nowEdge = (PT_now_uv[0].x - PT_now_uv[1].x) *
                                (PT_now_uv[0].x - PT_now_uv[1].x) +
                            (PT_now_uv[0].y - PT_now_uv[1].y) *
                                (PT_now_uv[0].y - PT_now_uv[1].y);

        // nextEdge像素边长
        int P_next_dst_ID = subdiv.edgeDst(nextEdge_ID);
        vector<Point2f> PT_next_uv(2);
        PT_next_uv[0] = subdiv.getVertex(P_org_ID);  // PT为 边两端的坐标
        PT_next_uv[1] = subdiv.getVertex(P_next_dst_ID);
        double d2_nextEdge = (PT_next_uv[0].x - PT_next_uv[1].x) *
                                 (PT_next_uv[0].x - PT_next_uv[1].x) +
                             (PT_next_uv[0].y - PT_next_uv[1].y) *
                                 (PT_next_uv[0].y - PT_next_uv[1].y);

        if (d2_nowEdge < thr.squareD_uv && d2_nextEdge < thr.squareD_uv) {
          int A_ID = P_org_ID;
          int B_ID = P_now_dst_ID;
          int C_ID = P_next_dst_ID;
          double A_x, A_y, A_z, B_x, B_y, B_z, C_x, C_y, C_z;

          A_x = double(uv_xyz[A_ID - 4][2]);
          A_y = double(uv_xyz[A_ID - 4][3]);
          A_z = double(uv_xyz[A_ID - 4][4]);

          B_x = double(uv_xyz[B_ID - 4][2]);
          B_y = double(uv_xyz[B_ID - 4][3]);
          B_z = double(uv_xyz[B_ID - 4][4]);

          C_x = double(uv_xyz[C_ID - 4][2]);
          C_y = double(uv_xyz[C_ID - 4][3]);
          C_z = double(uv_xyz[C_ID - 4][4]);

          double tri = 0;
          tri = Normal(A_x, A_y, A_z, B_x, B_y, B_z, C_x, C_y, C_z, tri);
          tri_sum = tri_sum + tri;
          counter++;
        }

        nowEdge_ID = nextEdge_ID;

        if (nowEdge_ID == *firstEdge) {
          break;
        }
      }  // while 结束

      if (counter != 0) {
        tri_average = tri_sum / counter;
      } else {
        tri_average = 1;
      }
      //判断障碍物点，0：地面，1：障碍物点
      if (tri_average < thr.average_normal_cos) {
        flag[p_ID] = 0;
      } else if (tri_average > thr.average_normal_cos && tri_average < 0.25) {
        flag[p_ID] = 2;
      } else {
        flag[p_ID] = 1;
      }
    }
  }  // for 循环结束。所有点计算完成

  if (is_show == 1)
  {
  for (size_t p_ID = 0; p_ID < points.size(); p_ID++) {
    if ((uv_xyz[p_ID][4]) <= -1) {
      if (flag[p_ID] != 2) {
        circle(img, points[p_ID], 1, Scalar(0, 0, flag[p_ID] * 255), -1);
      } else {
        circle(img, points[p_ID], 1, Scalar(0, 255, 0), -1);
      }
    }
  }
  }

}

//三角剖分结果可视化函数
void ShowTriangulationResult(Subdiv2D subdiv, Rect rect, Mat img) {
  //三角剖分结果显示
  vector<Vec6f> triangleList;
  subdiv.getTriangleList(triangleList);
  cout << "总三角形数" << triangleList.size() << endl;
  vector<Point2f> pt(3);
  Scalar delaunay_color(255, 0, 255);
  for (size_t jj = 0; jj < triangleList.size(); jj++) {
    Vec6f t = triangleList[jj];
    pt[0] = Point2f((t[0]), (t[1]));
    pt[1] = Point2f((t[2]), (t[3]));
    pt[2] = Point2f((t[4]), (t[5]));
    if (rect.contains(pt[0]) && rect.contains(pt[1]) &&
        rect.contains(pt[2])) {
      // 画图
      line(img, pt[0], pt[1], delaunay_color, 1, CV_AA, 0);
      line(img, pt[1], pt[2], delaunay_color, 1, CV_AA, 0);
      line(img, pt[2], pt[0], delaunay_color, 1, CV_AA, 0);
    }
  }
}
